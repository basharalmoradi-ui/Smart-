import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Auth from "./pages/Auth";
import ParkingList from "./pages/ParkingList";
import ReservationPage from "./pages/ReservationPage";
import BookingConfirmation from "./pages/BookingConfirmation";
import AdminDashboard from "./pages/AdminDashboard";
import ContactAbout from "./pages/ContactAbout";
import MyReservations from "./pages/MyReservations";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/auth"} component={Auth} />
      <Route path={"/parking"} component={ParkingList} />
      <Route path={"/reserve/:spotId"} component={ReservationPage} />
      <Route path={"/confirmation"} component={BookingConfirmation} />
      <Route path={"/reservations"} component={MyReservations} />
      <Route path={"/admin"} component={AdminDashboard} />
      <Route path={"/contact"} component={ContactAbout} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
