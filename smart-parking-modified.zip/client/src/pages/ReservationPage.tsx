import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { MapPin, Calendar, Clock, Car, DollarSign, ArrowRight } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

export default function ReservationPage(props: { params: { spotId: string } }) {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const spotId = parseInt(props.params.spotId || "0");

  const { data: spot } = trpc.parking.getById.useQuery(
    { id: spotId },
    { enabled: spotId > 0 }
  );

  const [startDate, setStartDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endDate, setEndDate] = useState("");
  const [endTime, setEndTime] = useState("");
  const [carNumber, setCarNumber] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const createReservation = trpc.reservations.create.useMutation();

  const totalPrice = useMemo(() => {
    if (!startDate || !startTime || !endDate || !endTime || !spot) return 0;

    const start = new Date(`${startDate}T${startTime}`);
    const end = new Date(`${endDate}T${endTime}`);
    const hours = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60));

    if (hours <= 0) return 0;

    return (hours * parseFloat(spot.pricePerHour.toString())).toFixed(2);
  }, [startDate, startTime, endDate, endTime, spot]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!startDate) newErrors.startDate = "تاريخ البداية مطلوب";
    if (!startTime) newErrors.startTime = "وقت البداية مطلوب";
    if (!endDate) newErrors.endDate = "تاريخ النهاية مطلوب";
    if (!endTime) newErrors.endTime = "وقت النهاية مطلوب";

    if (startDate && endDate) {
      const start = new Date(`${startDate}T${startTime || "00:00"}`);
      const end = new Date(`${endDate}T${endTime || "00:00"}`);

      if (start >= end) {
        newErrors.endTime = "تاريخ ووقت النهاية يجب أن يكون بعد البداية";
      }
    }

    if (!carNumber.trim()) {
      newErrors.carNumber = "رقم السيارة مطلوب";
    } else if (!/^[أ-ي0-9]{3,8}$/.test(carNumber.replace(/\s/g, ""))) {
      newErrors.carNumber = "رقم السيارة غير صحيح";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm() || !spot) return;

    const start = new Date(`${startDate}T${startTime}`);
    const end = new Date(`${endDate}T${endTime}`);

    try {
      const result = await createReservation.mutateAsync({
        spotId: spot.id,
        carNumber,
        startTime: start,
        endTime: end,
        totalPrice: totalPrice.toString(),
      });

      toast.success("تم إنشاء الحجز بنجاح!");
      setLocation(`/confirmation?code=${result.confirmationCode}`);
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء إنشاء الحجز");
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-[100vh] bg-white flex items-center justify-center p-4">
        <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 max-w-md text-center">
          <div className="space-y-4">
            <MapPin className="w-12 h-12 text-gray-600 mx-auto" />
            <h2 className="text-2xl font-bold text-gray-900">تسجيل الدخول مطلوب</h2>
            <Button
              onClick={() => window.location.href = "/auth"}
              className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
            >
              تسجيل الدخول
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  if (!spot) {
    return (
      <div className="min-h-[100vh] bg-white flex items-center justify-center p-4">
        <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 max-w-md text-center">
          <div className="space-y-4">
            <MapPin className="w-12 h-12 text-gray-600 mx-auto" />
            <h2 className="text-2xl font-bold text-gray-900">الموقف غير موجود</h2>
            <Button
              onClick={() => setLocation("/parking")}
              className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
            >
              العودة للمواقف
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-[100vh] bg-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/10 to-secondary/10 border-b border py-8">
        <div className="container">
          <div className="flex items-center gap-4 mb-4">
            <Button
              onClick={() => setLocation("/parking")}
              variant="ghost"
              className="gap-2"
            >
              <ArrowRight className="w-4 h-4" />
              العودة
            </Button>
          </div>
          <h1 className="text-3xl text-xl font-bold text-gray-900">حجز الموقف</h1>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid grid-cols-3 gap-8">
          {/* Reservation Form */}
          <div className="col-span-2">
            <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
              <form onSubmit={handleSubmit} className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">تفاصيل الحجز</h2>

                {/* Start Date & Time */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="form-group">
                    <label className="form-label">تاريخ البداية</label>
                    <div className="relative">
                      <Calendar className="absolute right-3 top-3 w-5 h-5 text-gray-600" />
                      <Input
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        className="pl-10 w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                      />
                    </div>
                    {errors.startDate && <p className="text-sm text-destructive mt-1">{errors.startDate}</p>}
                  </div>

                  <div className="form-group">
                    <label className="form-label">وقت البداية</label>
                    <div className="relative">
                      <Clock className="absolute right-3 top-3 w-5 h-5 text-gray-600" />
                      <Input
                        type="time"
                        value={startTime}
                        onChange={(e) => setStartTime(e.target.value)}
                        className="pl-10 w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                      />
                    </div>
                    {errors.startTime && <p className="text-sm text-destructive mt-1">{errors.startTime}</p>}
                  </div>
                </div>

                {/* End Date & Time */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="form-group">
                    <label className="form-label">تاريخ النهاية</label>
                    <div className="relative">
                      <Calendar className="absolute right-3 top-3 w-5 h-5 text-gray-600" />
                      <Input
                        type="date"
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                        className="pl-10 w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                      />
                    </div>
                    {errors.endDate && <p className="text-sm text-destructive mt-1">{errors.endDate}</p>}
                  </div>

                  <div className="form-group">
                    <label className="form-label">وقت النهاية</label>
                    <div className="relative">
                      <Clock className="absolute right-3 top-3 w-5 h-5 text-gray-600" />
                      <Input
                        type="time"
                        value={endTime}
                        onChange={(e) => setEndTime(e.target.value)}
                        className="pl-10 w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                      />
                    </div>
                    {errors.endTime && <p className="text-sm text-destructive mt-1">{errors.endTime}</p>}
                  </div>
                </div>

                {/* Car Number */}
                <div className="form-group">
                  <label className="form-label">رقم السيارة</label>
                  <div className="relative">
                    <Car className="absolute right-3 top-3 w-5 h-5 text-gray-600" />
                    <Input
                      type="text"
                      placeholder="أدخل رقم السيارة"
                      value={carNumber}
                      onChange={(e) => setCarNumber(e.target.value)}
                      className="pl-10 w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                  {errors.carNumber && <p className="text-sm text-destructive mt-1">{errors.carNumber}</p>}
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={createReservation.isPending}
                  className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
                >
                  {createReservation.isPending ? "جاري المعالجة..." : "تأكيد الحجز"}
                </Button>
              </form>
            </Card>
          </div>

          {/* Booking Summary */}
          <div>
            <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 sticky top-4">
              <h3 className="text-xl font-bold text-gray-900 mb-6">ملخص الحجز</h3>

              <div className="space-y-4 pb-6 border-b border">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-600">الموقف</p>
                    <p className="font-semibold text-gray-900">{spot.spotNumber}</p>
                    <p className="text-sm text-gray-600">{spot.location}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-600">الفترة</p>
                    <p className="font-semibold text-gray-900">
                      {startDate ? new Date(startDate).toLocaleDateString("ar-SA") : "غير محدد"}
                    </p>
                    <p className="text-sm text-gray-600">
                      {startTime} - {endTime}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <DollarSign className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-600">السعر</p>
                    <p className="font-semibold text-gray-900">
                      {spot.pricePerHour} ريال/ساعة
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-6 space-y-2">
                <div className="flex justify-between items-center">
                  <p className="text-gray-600">الإجمالي:</p>
                  <p className="text-2xl font-bold text-primary">{totalPrice} ريال</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
