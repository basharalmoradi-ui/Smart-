import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { MapPin, Mail, Lock, User, Phone } from "lucide-react";
import { useState } from "react";
import { Input } from "@/components/ui/input";

export default function Auth() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  if (isAuthenticated) {
    setLocation("/parking");
    return null;
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!isLogin && !formData.name.trim()) {
      newErrors.name = "الاسم مطلوب";
    }

    if (!formData.email.trim()) {
      newErrors.email = "البريد الإلكتروني مطلوب";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "البريد الإلكتروني غير صحيح";
    }

    if (!isLogin && !formData.phone.trim()) {
      newErrors.phone = "رقم الهاتف مطلوب";
    } else if (!isLogin && !/^\d{10,}$/.test(formData.phone.replace(/\D/g, ""))) {
      newErrors.phone = "رقم الهاتف غير صحيح";
    }

    if (!isLogin && !formData.password) {
      newErrors.password = "كلمة المرور مطلوبة";
    } else if (!isLogin && formData.password.length < 6) {
      newErrors.password = "كلمة المرور يجب أن تكون 6 أحرف على الأقل";
    }

    if (!isLogin && formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "كلمات المرور غير متطابقة";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      // In a real app, this would call an API
      console.log("Form submitted:", formData);
      // For now, redirect to login
      window.location.href = getLoginUrl();
    }
  };

  return (
    <div className="min-h-[100vh] bg-gradient-to-br from-primary/5 via-background to-secondary/5 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-4">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <MapPin className="w-7 h-7 text-white" />
            </div>
            <span className="text-2xl font-bold text-gray-900">SmartParking</span>
          </div>
          <p className="text-gray-600">
            {isLogin ? "تسجيل الدخول إلى حسابك" : "إنشاء حساب جديد"}
          </p>
        </div>

        {/* Form Card */}
        <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Name Field - Register Only */}
            {!isLogin && (
              <div className="form-group">
                <label className="form-label">الاسم الكامل</label>
                <div className="relative">
                  <User className="absolute right-3 top-3 w-5 h-5 text-gray-600" />
                  <Input
                    type="text"
                    placeholder="أدخل اسمك الكامل"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="pl-10 w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
                {errors.name && <p className="text-sm text-destructive mt-1">{errors.name}</p>}
              </div>
            )}

            {/* Email Field */}
            <div className="form-group">
              <label className="form-label">البريد الإلكتروني</label>
              <div className="relative">
                <Mail className="absolute right-3 top-3 w-5 h-5 text-gray-600" />
                <Input
                  type="email"
                  placeholder="أدخل بريدك الإلكتروني"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="pl-10 w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
              {errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}
            </div>

            {/* Phone Field - Register Only */}
            {!isLogin && (
              <div className="form-group">
                <label className="form-label">رقم الهاتف</label>
                <div className="relative">
                  <Phone className="absolute right-3 top-3 w-5 h-5 text-gray-600" />
                  <Input
                    type="tel"
                    placeholder="أدخل رقم هاتفك"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="pl-10 w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
                {errors.phone && <p className="text-sm text-destructive mt-1">{errors.phone}</p>}
              </div>
            )}

            {/* Password Field - Register Only */}
            {!isLogin && (
              <div className="form-group">
                <label className="form-label">كلمة المرور</label>
                <div className="relative">
                  <Lock className="absolute right-3 top-3 w-5 h-5 text-gray-600" />
                  <Input
                    type="password"
                    placeholder="أدخل كلمة المرور"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="pl-10 w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
                {errors.password && <p className="text-sm text-destructive mt-1">{errors.password}</p>}
              </div>
            )}

            {/* Confirm Password Field - Register Only */}
            {!isLogin && (
              <div className="form-group">
                <label className="form-label">تأكيد كلمة المرور</label>
                <div className="relative">
                  <Lock className="absolute right-3 top-3 w-5 h-5 text-gray-600" />
                  <Input
                    type="password"
                    placeholder="أعد إدخال كلمة المرور"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    className="pl-10 w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
                {errors.confirmPassword && <p className="text-sm text-destructive mt-1">{errors.confirmPassword}</p>}
              </div>
            )}

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
            >
              {isLogin ? "تسجيل الدخول" : "إنشاء حساب"}
            </Button>

            {/* OAuth Button */}
            <Button
              type="button"
              onClick={() => window.location.href = getLoginUrl()}
              className="w-full px-6 py-3 border-2 border-blue-600 text-blue-600 rounded-lg font-semibold hover:bg-blue-50"
            >
              {isLogin ? "تسجيل الدخول" : "إنشاء حساب"} عبر Manus
            </Button>

            {/* Toggle Auth Mode */}
            <div className="text-center pt-4 border-t border">
              <p className="text-sm text-gray-600 mb-2">
                {isLogin ? "ليس لديك حساب؟" : "هل لديك حساب بالفعل؟"}
              </p>
              <Button
                type="button"
                variant="ghost"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setErrors({});
                  setFormData({
                    name: "",
                    email: "",
                    phone: "",
                    password: "",
                    confirmPassword: "",
                  });
                }}
                className="text-primary hover:text-primary/80 font-semibold"
              >
                {isLogin ? "إنشاء حساب جديد" : "تسجيل الدخول"}
              </Button>
            </div>
          </form>
        </Card>

        {/* Info Text */}
        <p className="text-center text-xs text-gray-600 mt-6">
          بتسجيلك، فإنك توافق على شروط الخدمة وسياسة الخصوصية
        </p>
      </div>
    </div>
  );
}
