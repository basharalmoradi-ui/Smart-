import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { MapPin, Clock, DollarSign, Shield, Zap, BarChart3 } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  const features = [
    {
      icon: MapPin,
      title: "مواقف موزعة داخل الحرم الجامعي",
      description: "اختر من بين مئات المواقف المتاحة في جميع أنحاء المدينة",
    },
    {
      icon: Clock,
      title: "حجز خلال أقل من دقيقة",
      description: "احجز موقفك في ثوانٍ معدودة دون تعقيدات",
    },
    {
      icon: DollarSign,
      title: "رسوم مناسبة للطلاب والموظفين",
      description: "استمتع بأفضل الأسعار والعروض الخاصة",
    },
    {
      icon: Shield,
      title: "نظام موثوق لإدارة المواقف",
      description: "نظام حجز آمن مع ضمان كامل لحجزاتك",
    },
    {
      icon: Zap,
      title: "تأكيد الحجز مباشرة",
      description: "تأكيد تأكيد الحجز مباشرة الإلغاء في أي وقت",
    },
    {
      icon: BarChart3,
      title: "متابعة حالة المواقف",
      description: "تابع حجوزاتك وسجلك بسهولة",
    },
  ];

  return (
    <div className="min-h-[100vh] bg-white">
      {/* Navigation Bar */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-yellow-500 flex items-center justify-center">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">SmartParking</span>
          </div>

          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Button
                  variant="ghost"
                  onClick={() => setLocation("/parking")}
                  className="text-gray-900 hover:bg-gray-100"
                >
                  المواقف المتاحة
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => setLocation("/reservations")}
                  className="text-gray-900 hover:bg-gray-100"
                >
                  حجوزاتي
                </Button>
                {user?.role === 'admin' && (
                  <Button
                    variant="ghost"
                    onClick={() => setLocation("/admin")}
                    className="text-gray-900 hover:bg-gray-100"
                  >
                    لوحة التحكم
                  </Button>
                )}
              </>
            ) : null}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-white to-yellow-50 py-20 py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl text-4xl font-bold text-gray-900 leading-tight">
                  جد موقفك <span className="bg-gradient-to-r from-blue-600 to-yellow-500 bg-clip-text text-transparent">بسهولة</span>
                </h1>
                <p className="text-lg text-gray-600 max-w-lg">
                  نظام حجز مواقف ذكي يوفر لك تجربة فريدة وسهلة. احجز موقفك المفضل في ثوانٍ معدودة.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                {isAuthenticated ? (
                  <>
                    <Button
                      onClick={() => setLocation("/parking")}
                      className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
                    >
                      ابدأ الحجز الآن
                    </Button>
                    <Button
                      onClick={() => setLocation("/reservations")}
                      className="px-6 py-3 border-2 border-blue-600 text-blue-600 rounded-lg font-semibold hover:bg-blue-50"
                    >
                      حجوزاتي
                    </Button>
                  </>
                ) : (
                  <>
                    <Button
                      onClick={() => window.location.href = getLoginUrl()}
                      className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
                    >
                      تسجيل الدخول
                    </Button>
                    <Button
                      onClick={() => window.location.href = getLoginUrl()}
                      className="px-6 py-3 border-2 border-blue-600 text-blue-600 rounded-lg font-semibold hover:bg-blue-50"
                    >
                      إنشاء حساب
                    </Button>
                  </>
                )}
              </div>

              <div className="flex items-center gap-6 pt-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-600">1000+</p>
                  <p className="text-sm text-gray-600">موقف متاح</p>
                </div>
                <div className="w-px h-12 bg-gray-300"></div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-600">5000+</p>
                  <p className="text-sm text-gray-600">مستخدم نشط</p>
                </div>
                <div className="w-px h-12 bg-gray-300"></div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-600">24/7</p>
                  <p className="text-sm text-gray-600">خدمة مستمرة</p>
                </div>
              </div>
            </div>

            <div className="hidden block">
              <div className="relative w-full h-96 bg-gradient-to-br from-blue-200/50 to-yellow-200/50 rounded-2xl flex items-center justify-center border border-gray-300">
                <div className="text-center">
                  <MapPin className="w-24 h-24 text-blue-400/40 mx-auto mb-4" />
                  <p className="text-gray-600">صورة توضيحية</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl text-3xl font-bold text-gray-900 mb-4">مميزات النظام</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              نوفر لك أفضل الخدمات والمميزات لتجربة حجز سلسة وممتعة
            </p>
          </div>

          <div className="grid grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow p-6 border border-gray-200 hover:-translate-y-1">
                  <div className="flex flex-col items-start gap-4">
                    <div className="p-3 rounded-lg bg-blue-100">
                      <Icon className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        {feature.title}
                      </h3>
                      <p className="text-gray-600">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 py-32 bg-gradient-to-r from-blue-100/50 to-yellow-100/50 border-y border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
          <div className="space-y-4">
            <h2 className="text-3xl text-3xl font-bold text-gray-900">
              هل أنت مستعد للبدء؟
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              احجز موقفك الآن واستمتع بتجربة حجز سهلة وآمنة
            </p>
          </div>

          {!isAuthenticated && (
            <Button
              onClick={() => window.location.href = getLoginUrl()}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 mx-auto"
            >
              ابدأ الآن مجانًا
            </Button>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-50 border-t border-gray-200 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">عن التطبيق</h4>
              <p className="text-sm text-gray-600">
                نظام حجز مواقف ذكي يوفر تجربة فريدة وسهلة للمستخدمين
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">روابط سريعة</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-blue-600 transition">الرئيسية</a></li>
                <li><a href="#" className="hover:text-blue-600 transition">المواقف</a></li>
                <li><a href="#" className="hover:text-blue-600 transition">حول التطبيق</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">الدعم</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-blue-600 transition">اتصل بنا</a></li>
                <li><a href="#" className="hover:text-blue-600 transition">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-blue-600 transition">سياسة الخصوصية</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">تابعنا</h4>
              <p className="text-sm text-gray-600">
                تابع أحدث أخبارنا على وسائل التواصل الاجتماعي
              </p>
            </div>
          </div>

          <div className="border-t border-gray-200 pt-8 text-center text-sm text-gray-600">
            <p>&copy; 2026 SmartParking. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
