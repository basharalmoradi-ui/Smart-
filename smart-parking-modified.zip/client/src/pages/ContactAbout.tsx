import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { Mail, Phone, MapPin, Clock, Send, MessageSquare } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function ContactAbout() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) newErrors.name = "الاسم مطلوب";
    if (!formData.email.trim()) newErrors.email = "البريد الإلكتروني مطلوب";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "البريد الإلكتروني غير صحيح";
    }
    if (!formData.subject.trim()) newErrors.subject = "الموضوع مطلوب";
    if (!formData.message.trim()) newErrors.message = "الرسالة مطلوبة";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (validateForm()) {
      toast.success("تم إرسال رسالتك بنجاح. سنرد عليك قريبًا.");
      setFormData({ name: "", email: "", subject: "", message: "" });
    }
  };

  return (
    <div className="min-h-[100vh] bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <Button
            onClick={() => setLocation("/")}
            variant="ghost"
            className="text-gray-900 hover:bg-muted"
          >
            ← العودة
          </Button>
          <span className="text-xl font-bold text-gray-900">SmartParking</span>
          <div className="w-20"></div>
        </div>
      </nav>

      {/* About Section */}
      <section className="bg-gradient-to-br from-primary/5 via-background to-secondary/5 py-16 py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl text-xl font-bold text-gray-900 mb-6">
              عن <span className="bg-gradient-to-r from-blue-600 to-yellow-500 bg-clip-text text-transparent">SmartParking</span>
            </h1>

            <div className="space-y-6 text-lg text-gray-600">
              <p>
                نحن نؤمن أن البحث عن موقف للسيارة لا يجب أن يكون مرهقًا. لذلك طورنا SmartParking، 
                منصة ذكية تجعل حجز المواقف سهلاً وسريعًا وآمنًا.
              </p>

              <p>
                مع أكثر من 1000 موقف متاح و 5000 مستخدم نشط، نحن نقدم أفضل تجربة حجز في المدينة. 
                فريقنا يعمل 24/7 لضمان رضاك التام.
              </p>

              <p>
                رؤيتنا هي جعل المدينة أكثر ذكاءً وكفاءة من خلال تقليل الوقت الضائع في البحث عن المواقف، 
                وبالتالي تقليل الازدحام والتلوث.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-6 mt-12">
              <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 text-center">
                <div className="text-4xl font-bold text-primary mb-2">1000+</div>
                <p className="text-gray-600">موقف متاح</p>
              </Card>
              <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 text-center">
                <div className="text-4xl font-bold text-primary mb-2">5000+</div>
                <p className="text-gray-600">مستخدم نشط</p>
              </Card>
              <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 text-center">
                <div className="text-4xl font-bold text-primary mb-2">24/7</div>
                <p className="text-gray-600">خدمة مستمرة</p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 py-24">
        <div className="container">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl text-xl font-bold text-gray-900 mb-4">
                تواصل معنا
              </h2>
              <p className="text-lg text-gray-600">
                لديك أسئلة أو تعليقات؟ نحن هنا للمساعدة
              </p>
            </div>

            <div className="grid grid-cols-2 gap-8">
              {/* Contact Form */}
              <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <h3 className="text-xl font-bold text-gray-900">أرسل لنا رسالة</h3>

                  <div className="form-group">
                    <label className="form-label">الاسم</label>
                    <Input
                      type="text"
                      placeholder="أدخل اسمك"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                    {errors.name && <p className="text-sm text-destructive mt-1">{errors.name}</p>}
                  </div>

                  <div className="form-group">
                    <label className="form-label">البريد الإلكتروني</label>
                    <Input
                      type="email"
                      placeholder="أدخل بريدك الإلكتروني"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                    {errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}
                  </div>

                  <div className="form-group">
                    <label className="form-label">الموضوع</label>
                    <Input
                      type="text"
                      placeholder="موضوع الرسالة"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                    {errors.subject && <p className="text-sm text-destructive mt-1">{errors.subject}</p>}
                  </div>

                  <div className="form-group">
                    <label className="form-label">الرسالة</label>
                    <textarea
                      placeholder="اكتب رسالتك هنا..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      rows={5}
                      className="w-full px-4 py-3 rounded-lg border border bg-white text-gray-900 placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    {errors.message && <p className="text-sm text-destructive mt-1">{errors.message}</p>}
                  </div>

                  <Button type="submit" className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 flex items-center justify-center gap-2">
                    <Send className="w-4 h-4" />
                    إرسال الرسالة
                  </Button>
                </form>
              </Card>

              {/* Contact Info */}
              <div className="space-y-6">
                <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-primary/10">
                      <Phone className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">الهاتف</h4>
                      <p className="text-gray-600">0500000000</p>
                      <p className="text-gray-600">0500000001</p>
                    </div>
                  </div>
                </Card>

                <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-primary/10">
                      <Mail className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">البريد الإلكتروني</h4>
                      <p className="text-gray-600">support@smartparking.com</p>
                      <p className="text-gray-600">info@smartparking.com</p>
                    </div>
                  </div>
                </Card>

                <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-primary/10">
                      <MapPin className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">العنوان</h4>
                      <p className="text-gray-600">
                        شارع الملك فهد<br />
                        الرياض، المملكة العربية السعودية
                      </p>
                    </div>
                  </div>
                </Card>

                <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-primary/10">
                      <Clock className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">ساعات العمل</h4>
                      <p className="text-gray-600">
                        السبت - الخميس: 8:00 - 20:00<br />
                        الجمعة: 10:00 - 18:00
                      </p>
                    </div>
                  </div>
                </Card>

                <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 bg-gradient-to-br from-primary/10 to-secondary/10 border-primary/20">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-primary/20">
                      <MessageSquare className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">الدعم الفوري</h4>
                      <p className="text-gray-600 mb-3">
                        تحدث معنا عبر الدردشة الحية
                      </p>
                      <Button className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 w-full">
                        ابدأ الدردشة
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="bg-muted/30 py-16 py-24">
        <div className="container max-w-3xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl text-xl font-bold text-gray-900 mb-4">
              الأسئلة الشائعة
            </h2>
          </div>

          <div className="space-y-4">
            {[
              {
                q: "كيف أحجز موقفًا؟",
                a: "ما عليك سوى تسجيل الدخول، اختيار موقف متاح، وتأكيد الحجز. ستتلقى رقم تأكيد فورًا.",
              },
              {
                q: "هل يمكنني إلغاء حجزي؟",
                a: "نعم، يمكنك إلغاء الحجز قبل ساعتين من موعد البداية واسترجاع المبلغ كاملاً.",
              },
              {
                q: "كيف أدفع؟",
                a: "نقبل جميع طرق الدفع الرئيسية: بطاقات الائتمان، التحويل البنكي، والمحافظ الرقمية.",
              },
              {
                q: "هل هناك رسوم إضافية؟",
                a: "لا، السعر المعروض هو السعر النهائي. لا توجد رسوم مخفية.",
              },
            ].map((item, index) => (
              <Card key={index} className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
                <h4 className="font-semibold text-gray-900 mb-2">{item.q}</h4>
                <p className="text-gray-600">{item.a}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground/5 border-t border py-12">
        <div className="container text-center text-sm text-gray-600">
          <p>&copy; 2026 SmartParking. جميع الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  );
}
