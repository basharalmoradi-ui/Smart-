import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { MapPin, Calendar, Clock, Car, DollarSign, Eye, Trash2, MapPinOff } from "lucide-react";
import { toast } from "sonner";

export default function MyReservations() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  const { data: reservations = [], isLoading } = trpc.reservations.myReservations.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const cancelReservation = trpc.reservations.cancel.useMutation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-[100vh] bg-white flex items-center justify-center p-4">
        <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 max-w-md text-center">
          <div className="space-y-4">
            <MapPin className="w-12 h-12 text-gray-600 mx-auto" />
            <h2 className="text-2xl font-bold text-gray-900">تسجيل الدخول مطلوب</h2>
            <Button
              onClick={() => window.location.href = getLoginUrl()}
              className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
            >
              تسجيل الدخول
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  const handleCancel = async (id: number) => {
    if (!window.confirm("هل تريد إلغاء هذا الحجز؟")) return;

    try {
      await cancelReservation.mutateAsync({ id });
      toast.success("تم إلغاء الحجز بنجاح");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ");
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-700';
      case 'cancelled':
        return 'bg-red-100 text-red-700';
      case 'pending':
        return 'bg-yellow-100 text-yellow-700';
      case 'completed':
        return 'bg-blue-100 text-blue-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'مؤكد';
      case 'cancelled':
        return 'ملغى';
      case 'pending':
        return 'قيد الانتظار';
      case 'completed':
        return 'مكتمل';
      default:
        return status;
    }
  };

  return (
    <div className="min-h-[100vh] bg-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/10 to-secondary/10 border-b border py-8">
        <div className="container">
          <h1 className="text-3xl text-xl font-bold text-gray-900 mb-2">حجوزاتي</h1>
          <p className="text-gray-600">عرض وإدارة جميع حجوزاتك</p>
        </div>
      </div>

      <div className="container py-8">
        {isLoading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin">
              <MapPin className="w-8 h-8 text-primary" />
            </div>
            <p className="text-gray-600 mt-4">جاري التحميل...</p>
          </div>
        ) : reservations.length === 0 ? (
          <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 text-center py-12">
            <MapPinOff className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">لا توجد حجوزات</h3>
            <p className="text-gray-600 mb-6">
              لم تقم بأي حجوزات حتى الآن. ابدأ بحجز موقفك الآن!
            </p>
            <Button
              onClick={() => setLocation("/parking")}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
            >
              ابحث عن مواقف
            </Button>
          </Card>
        ) : (
          <div className="space-y-4">
            {reservations.map((reservation) => (
              <Card key={reservation.id} className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
                <div className="grid grid-cols-5 gap-4 items-start">
                  {/* Confirmation Code */}
                  <div>
                    <p className="text-sm text-gray-600 mb-1">رقم التأكيد</p>
                    <p className="font-mono font-semibold text-gray-900 break-all">
                      {reservation.confirmationCode}
                    </p>
                  </div>

                  {/* Car & Spot */}
                  <div>
                    <p className="text-sm text-gray-600 mb-1">السيارة والموقف</p>
                    <p className="font-semibold text-gray-900">{reservation.carNumber}</p>
                    <p className="text-sm text-gray-600">موقف #{reservation.spotId}</p>
                  </div>

                  {/* Dates & Times */}
                  <div>
                    <p className="text-sm text-gray-600 mb-1">الفترة</p>
                    <p className="font-semibold text-gray-900">
                      {new Date(reservation.startTime).toLocaleDateString("ar-SA")}
                    </p>
                    <p className="text-sm text-gray-600">
                      {new Date(reservation.startTime).toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" })} -
                      {new Date(reservation.endTime).toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>

                  {/* Price & Status */}
                  <div>
                    <p className="text-sm text-gray-600 mb-1">الإجمالي والحالة</p>
                    <p className="font-semibold text-primary mb-2">{reservation.totalPrice} ريال</p>
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(reservation.status)}`}>
                      {getStatusLabel(reservation.status)}
                    </span>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 justify-end">
                    <Button
                      size="sm"
                      onClick={() => setLocation(`/confirmation?code=${reservation.confirmationCode}`)}
                      className="px-6 py-3 border-2 border-blue-600 text-blue-600 rounded-lg font-semibold hover:bg-blue-50 flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      <span className="hidden sm:inline">عرض</span>
                    </Button>
                    {reservation.status === 'confirmed' && (
                      <Button
                        size="sm"
                        onClick={() => handleCancel(reservation.id)}
                        disabled={cancelReservation.isPending}
                        variant="destructive"
                        className="flex items-center gap-1"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span className="hidden sm:inline">إلغاء</span>
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
