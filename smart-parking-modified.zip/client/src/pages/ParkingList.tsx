import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { MapPin, DollarSign, Zap, Search, Filter, MapPinOff } from "lucide-react";
import { useState, useMemo } from "react";

export default function ParkingList() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [searchLocation, setSearchLocation] = useState("");
  const [maxPrice, setMaxPrice] = useState<number | null>(null);
  const [spotType, setSpotType] = useState<string>("");

  const { data: spots = [], isLoading } = trpc.parking.available.useQuery();

  const filteredSpots = useMemo(() => {
    return spots.filter((spot) => {
      const matchesLocation = spot.location.toLowerCase().includes(searchLocation.toLowerCase());
      const matchesPrice = maxPrice === null || parseFloat(spot.pricePerHour.toString()) <= maxPrice;
      const matchesType = spotType === "" || spot.spotType === spotType;
      return matchesLocation && matchesPrice && matchesType;
    });
  }, [spots, searchLocation, maxPrice, spotType]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-[100vh] bg-white flex items-center justify-center p-4">
        <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 max-w-md text-center">
          <div className="space-y-4">
            <MapPinOff className="w-12 h-12 text-gray-600 mx-auto" />
            <h2 className="text-2xl font-bold text-gray-900">تسجيل الدخول مطلوب</h2>
            <p className="text-gray-600">
              يجب عليك تسجيل الدخول لعرض المواقف المتاحة
            </p>
            <Button
              onClick={() => window.location.href = getLoginUrl()}
              className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
            >
              تسجيل الدخول
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-[100vh] bg-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/10 to-secondary/10 border-b border py-8">
        <div className="container">
          <h1 className="text-3xl text-xl font-bold text-gray-900 mb-2">المواقف المتاحة</h1>
          <p className="text-gray-600">اختر الموقف المناسب لسيارتك</p>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid grid-cols-4 gap-6 mb-8">
          {/* Search & Filters */}
          <div className="col-span-1 space-y-4">
            <div className="bg-white rounded-lg border border p-4 space-y-4">
              <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                <Filter className="w-5 h-5" />
                تصفية النتائج
              </h3>

              {/* Location Search */}
              <div>
                <label className="form-label">البحث عن الموقع</label>
                <div className="relative">
                  <Search className="absolute right-3 top-3 w-4 h-4 text-gray-600" />
                  <Input
                    type="text"
                    placeholder="ابحث عن الموقع..."
                    value={searchLocation}
                    onChange={(e) => setSearchLocation(e.target.value)}
                    className="pl-4 w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
              </div>

              {/* Price Filter */}
              <div>
                <label className="form-label">السعر الأقصى (ريال/ساعة)</label>
                <Input
                  type="number"
                  placeholder="أدخل السعر الأقصى"
                  value={maxPrice || ""}
                  onChange={(e) => setMaxPrice(e.target.value ? parseFloat(e.target.value) : null)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              {/* Spot Type Filter */}
              <div>
                <label className="form-label">نوع الموقف</label>
                <select
                  value={spotType}
                  onChange={(e) => setSpotType(e.target.value)}
                  className="w-full px-4 py-2 rounded-lg border border bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="">الكل</option>
                  <option value="standard">عادي</option>
                  <option value="compact">صغير</option>
                  <option value="accessible">معاق</option>
                </select>
              </div>

              {/* Clear Filters */}
              <Button
                onClick={() => {
                  setSearchLocation("");
                  setMaxPrice(null);
                  setSpotType("");
                }}
                variant="outline"
                className="w-full"
              >
                مسح الفلاتر
              </Button>
            </div>
          </div>

          {/* Parking Spots Grid */}
          <div className="col-span-3">
            {isLoading ? (
              <div className="text-center py-12">
                <div className="inline-block animate-spin">
                  <Zap className="w-8 h-8 text-primary" />
                </div>
                <p className="text-gray-600 mt-4">جاري التحميل...</p>
              </div>
            ) : filteredSpots.length === 0 ? (
              <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 text-center py-12">
                <MapPinOff className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">لا توجد مواقف متاحة</h3>
                <p className="text-gray-600">
                  جرب تغيير معايير البحث
                </p>
              </Card>
            ) : (
              <div className="grid gap-6">
                {filteredSpots.map((spot) => (
                  <Card key={spot.id} className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 hover-lift">
                    <div className="flex flex-col flex-row items-center justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-start gap-4">
                          <div className="p-3 rounded-lg bg-primary/10">
                            <MapPin className="w-6 h-6 text-primary" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="text-lg font-semibold text-gray-900">
                                {spot.spotNumber}
                              </h3>
                              <span className="badge-primary">
                                {spot.spotType === 'standard' ? 'عادي' : spot.spotType === 'compact' ? 'صغير' : 'معاق'}
                              </span>
                            </div>
                            <p className="text-gray-600 mb-2">{spot.location}</p>
                            {spot.description && (
                              <p className="text-sm text-gray-600">{spot.description}</p>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-6 flex-col items-end">
                        <div className="text-right">
                          <p className="text-sm text-gray-600">السعر</p>
                          <div className="flex items-center gap-1">
                            <DollarSign className="w-4 h-4 text-primary" />
                            <p className="text-2xl font-bold text-primary">
                              {spot.pricePerHour}
                            </p>
                            <span className="text-sm text-gray-600">/ساعة</span>
                          </div>
                        </div>

                        <Button
                          onClick={() => setLocation(`/reserve/${spot.id}`)}
                          className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 whitespace-nowrap"
                        >
                          احجز الآن
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}

            {/* Results Count */}
            {!isLoading && filteredSpots.length > 0 && (
              <p className="text-sm text-gray-600 mt-6 text-center">
                عرض {filteredSpots.length} من {spots.length} موقف متاح
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
