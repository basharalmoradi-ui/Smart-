import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { MapPin, Calendar, Clock, Car, DollarSign, CheckCircle, Download, Share2, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function BookingConfirmation() {
  const [, setLocation] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const confirmationCode = params.get("code") || "";
  const [showCancelDialog, setShowCancelDialog] = useState(false);

  const { data: reservation } = trpc.reservations.getByCode.useQuery(
    { code: confirmationCode },
    { enabled: !!confirmationCode }
  );

  const { data: spot } = trpc.parking.getById.useQuery(
    { id: reservation?.spotId || 0 },
    { enabled: !!reservation }
  );

  const cancelReservation = trpc.reservations.cancel.useMutation();

  const handleCancel = async () => {
    if (!reservation) return;

    try {
      await cancelReservation.mutateAsync({ id: reservation.id });
      toast.success("تم إلغاء الحجز بنجاح");
      setLocation("/parking");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء إلغاء الحجز");
    }
  };

  const handleDownload = () => {
    // In a real app, this would generate a PDF
    toast.success("جاري تحميل الحجز...");
  };

  const handleShare = () => {
    const text = `تم حجز الموقف ${spot?.spotNumber} برقم تأكيد: ${confirmationCode}`;
    if (navigator.share) {
      navigator.share({ title: "تأكيد الحجز", text });
    } else {
      navigator.clipboard.writeText(text);
      toast.success("تم نسخ التفاصيل");
    }
  };

  if (!reservation || !spot) {
    return (
      <div className="min-h-[100vh] bg-white flex items-center justify-center p-4">
        <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 max-w-md text-center">
          <div className="space-y-4">
            <MapPin className="w-12 h-12 text-gray-600 mx-auto" />
            <h2 className="text-2xl font-bold text-gray-900">الحجز غير موجود</h2>
            <Button
              onClick={() => setLocation("/")}
              className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
            >
              العودة للرئيسية
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  const startDate = new Date(reservation.startTime);
  const endDate = new Date(reservation.endTime);

  return (
    <div className="min-h-[100vh] bg-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/10 to-secondary/10 border-b border py-8">
        <div className="container text-center">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h1 className="text-3xl text-xl font-bold text-gray-900 mb-2">
            تم تأكيد الحجز بنجاح!
          </h1>
          <p className="text-gray-600">
            احفظ رقم التأكيد للرجوع إلى حجزك في أي وقت
          </p>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid grid-cols-3 gap-8 mb-8">
          {/* Main Confirmation Card */}
          <div className="col-span-2">
            <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
              <div className="space-y-8">
                {/* Confirmation Code */}
                <div className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg p-6 text-center border border-primary/20">
                  <p className="text-sm text-gray-600 mb-2">رقم التأكيد</p>
                  <p className="text-3xl font-bold text-primary font-mono">
                    {confirmationCode}
                  </p>
                  <p className="text-xs text-gray-600 mt-2">
                    احفظ هذا الرقم للرجوع إلى حجزك
                  </p>
                </div>

                {/* Booking Details */}
                <div className="space-y-4">
                  <h2 className="text-xl font-bold text-gray-900">تفاصيل الحجز</h2>

                  <div className="grid grid-cols-2 gap-6">
                    {/* Parking Spot */}
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-primary/10">
                        <MapPin className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">الموقف</p>
                        <p className="font-semibold text-gray-900 text-lg">{spot.spotNumber}</p>
                        <p className="text-sm text-gray-600">{spot.location}</p>
                      </div>
                    </div>

                    {/* Car Number */}
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-primary/10">
                        <Car className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">رقم السيارة</p>
                        <p className="font-semibold text-gray-900 text-lg">{reservation.carNumber}</p>
                      </div>
                    </div>

                    {/* Start Date & Time */}
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-primary/10">
                        <Calendar className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">تاريخ البداية</p>
                        <p className="font-semibold text-gray-900">
                          {startDate.toLocaleDateString("ar-SA")}
                        </p>
                        <p className="text-sm text-gray-600">
                          {startDate.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                    </div>

                    {/* End Date & Time */}
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-primary/10">
                        <Clock className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">تاريخ النهاية</p>
                        <p className="font-semibold text-gray-900">
                          {endDate.toLocaleDateString("ar-SA")}
                        </p>
                        <p className="text-sm text-gray-600">
                          {endDate.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                    </div>

                    {/* Total Price */}
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-primary/10">
                        <DollarSign className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">الإجمالي</p>
                        <p className="font-semibold text-gray-900 text-lg">
                          {reservation.totalPrice} ريال
                        </p>
                      </div>
                    </div>

                    {/* Status */}
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-green-100">
                        <CheckCircle className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">الحالة</p>
                        <p className="font-semibold text-gray-900 text-lg">
                          {reservation.status === 'confirmed' ? 'مؤكد' : 'قيد الانتظار'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="border-t border pt-6 space-y-3">
                  <div className="grid grid-cols-3 gap-3">
                    <Button
                      onClick={handleDownload}
                      className="px-6 py-3 border-2 border-blue-600 text-blue-600 rounded-lg font-semibold hover:bg-blue-50 flex items-center justify-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      تحميل
                    </Button>
                    <Button
                      onClick={handleShare}
                      className="px-6 py-3 border-2 border-blue-600 text-blue-600 rounded-lg font-semibold hover:bg-blue-50 flex items-center justify-center gap-2"
                    >
                      <Share2 className="w-4 h-4" />
                      مشاركة
                    </Button>
                    <Button
                      onClick={() => setShowCancelDialog(true)}
                      variant="destructive"
                      className="flex items-center justify-center gap-2"
                    >
                      <Trash2 className="w-4 h-4" />
                      إلغاء الحجز
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Info Card */}
          <div>
            <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
              <h3 className="text-lg font-bold text-gray-900 mb-4">معلومات مهمة</h3>
              <div className="space-y-4 text-sm text-gray-600">
                <div>
                  <p className="font-semibold text-gray-900 mb-1">الوصول المبكر</p>
                  <p>يمكنك الوصول 15 دقيقة قبل الموعد المحدد</p>
                </div>
                <div>
                  <p className="font-semibold text-gray-900 mb-1">الإلغاء</p>
                  <p>يمكنك إلغاء الحجز قبل 2 ساعة من الموعد</p>
                </div>
                <div>
                  <p className="font-semibold text-gray-900 mb-1">الدعم</p>
                  <p>للمساعدة، اتصل بنا على 0500000000</p>
                </div>
              </div>
            </Card>

            <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 mt-4">
              <h3 className="text-lg font-bold text-gray-900 mb-4">الخطوات التالية</h3>
              <ol className="space-y-3 text-sm">
                <li className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">1</span>
                  <span className="text-gray-600">احفظ رقم التأكيد</span>
                </li>
                <li className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">2</span>
                  <span className="text-gray-600">توجه للموقف قبل الموعد</span>
                </li>
                <li className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">3</span>
                  <span className="text-gray-600">أكمل الدفع عند الوصول</span>
                </li>
              </ol>
            </Card>
          </div>
        </div>

        {/* Cancel Dialog */}
        {showCancelDialog && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 max-w-md">
              <div className="space-y-4">
                <h3 className="text-xl font-bold text-gray-900">هل تريد إلغاء الحجز؟</h3>
                <p className="text-gray-600">
                  هذا الإجراء لا يمكن التراجع عنه. سيتم استرجاع المبلغ إلى حسابك.
                </p>
                <div className="flex gap-3">
                  <Button
                    onClick={() => setShowCancelDialog(false)}
                    variant="outline"
                    className="flex-1"
                  >
                    إلغاء
                  </Button>
                  <Button
                    onClick={handleCancel}
                    disabled={cancelReservation.isPending}
                    variant="destructive"
                    className="flex-1"
                  >
                    {cancelReservation.isPending ? "جاري..." : "تأكيد الإلغاء"}
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Back Button */}
        <div className="text-center mt-8">
          <Button
            onClick={() => setLocation("/")}
            className="px-6 py-3 border-2 border-blue-600 text-blue-600 rounded-lg font-semibold hover:bg-blue-50"
          >
            العودة للرئيسية
          </Button>
        </div>
      </div>
    </div>
  );
}
