import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { BarChart3, Users, MapPin, TrendingUp, Plus, Edit2, Trash2, Eye } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [showAddSpot, setShowAddSpot] = useState(false);
  const [formData, setFormData] = useState({
    spotNumber: "",
    location: "",
    floor: "",
    pricePerHour: "",
    spotType: "standard" as const,
  });

  // Redirect if not admin
  if (user?.role !== 'admin') {
    setLocation("/");
    return null;
  }

  const { data: stats } = trpc.stats.parking.useQuery();
  const { data: reservationStats } = trpc.stats.reservations.useQuery();
  const { data: spots = [] } = trpc.parking.list.useQuery();
  const { data: reservations = [] } = trpc.reservations.all.useQuery();

  const createSpot = trpc.parking.create.useMutation();
  const deleteSpot = trpc.parking.delete.useMutation();

  const handleAddSpot = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.spotNumber || !formData.location || !formData.floor || !formData.pricePerHour) {
      toast.error("جميع الحقول مطلوبة");
      return;
    }

    try {
      await createSpot.mutateAsync({
        spotNumber: formData.spotNumber,
        location: formData.location,
        floor: parseInt(formData.floor),
        pricePerHour: formData.pricePerHour,
        spotType: formData.spotType,
      });

      toast.success("تم إضافة الموقف بنجاح");
      setShowAddSpot(false);
      setFormData({
        spotNumber: "",
        location: "",
        floor: "",
        pricePerHour: "",
        spotType: "standard",
      });
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ");
    }
  };

  const handleDeleteSpot = async (id: number) => {
    if (!window.confirm("هل تريد حذف هذا الموقف؟")) return;

    try {
      await deleteSpot.mutateAsync({ id });
      toast.success("تم حذف الموقف بنجاح");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ");
    }
  };

  return (
    <div className="min-h-[100vh] bg-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/10 to-secondary/10 border-b border py-8">
        <div className="container">
          <h1 className="text-3xl text-xl font-bold text-gray-900 mb-2">لوحة التحكم</h1>
          <p className="text-gray-600">إدارة المواقف والحجوزات والإحصائيات</p>
        </div>
      </div>

      <div className="container py-8">
        {/* Statistics Cards */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">إجمالي المواقف</p>
                <p className="text-3xl font-bold text-primary">{stats?.total || 0}</p>
              </div>
              <MapPin className="w-8 h-8 text-primary/20" />
            </div>
          </Card>

          <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">المتاحة</p>
                <p className="text-3xl font-bold text-green-600">{stats?.available || 0}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600/20" />
            </div>
          </Card>

          <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">الحجوزات</p>
                <p className="text-3xl font-bold text-primary">{reservationStats?.total || 0}</p>
              </div>
              <Users className="w-8 h-8 text-primary/20" />
            </div>
          </Card>

          <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">المؤكدة</p>
                <p className="text-3xl font-bold text-blue-600">{reservationStats?.confirmed || 0}</p>
              </div>
              <BarChart3 className="w-8 h-8 text-blue-600/20" />
            </div>
          </Card>
        </div>

        {/* Tabs */}
        <div className="grid grid-cols-2 gap-8">
          {/* Parking Spots Section */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">المواقف</h2>
              <Button
                onClick={() => setShowAddSpot(!showAddSpot)}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                إضافة موقف
              </Button>
            </div>

            {showAddSpot && (
              <Card className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200 mb-6">
                <form onSubmit={handleAddSpot} className="space-y-4">
                  <input
                    type="text"
                    placeholder="رقم الموقف"
                    value={formData.spotNumber}
                    onChange={(e) => setFormData({ ...formData, spotNumber: e.target.value })}
                    className="w-full w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                  <input
                    type="text"
                    placeholder="الموقع"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                  <input
                    type="number"
                    placeholder="الطابق"
                    value={formData.floor}
                    onChange={(e) => setFormData({ ...formData, floor: e.target.value })}
                    className="w-full w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                  <input
                    type="number"
                    placeholder="السعر (ريال/ساعة)"
                    value={formData.pricePerHour}
                    onChange={(e) => setFormData({ ...formData, pricePerHour: e.target.value })}
                    className="w-full w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                  <select
                    value={formData.spotType}
                    onChange={(e) => setFormData({ ...formData, spotType: e.target.value as any })}
                    className="w-full px-4 py-2 rounded-lg border border bg-white"
                  >
                    <option value="standard">عادي</option>
                    <option value="compact">صغير</option>
                    <option value="accessible">معاق</option>
                  </select>
                  <div className="flex gap-2">
                    <Button type="submit" className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700" disabled={createSpot.isPending}>
                      {createSpot.isPending ? "جاري..." : "إضافة"}
                    </Button>
                    <Button
                      type="button"
                      onClick={() => setShowAddSpot(false)}
                      variant="outline"
                      className="flex-1"
                    >
                      إلغاء
                    </Button>
                  </div>
                </form>
              </Card>
            )}

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {spots.map((spot) => (
                <Card key={spot.id} className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="font-semibold text-gray-900">{spot.spotNumber}</p>
                      <p className="text-sm text-gray-600">{spot.location}</p>
                      <p className="text-sm text-primary">{spot.pricePerHour} ريال/ساعة</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-blue-600 hover:bg-blue-50"
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDeleteSpot(spot.id)}
                        className="text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Reservations Section */}
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">الحجوزات الأخيرة</h2>

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {reservations.slice(0, 10).map((reservation) => (
                <Card key={reservation.id} className="bg-white rounded-xl shadow-md hover:shadow-lg p-6 border border-gray-200">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="font-semibold text-gray-900">
                        رقم التأكيد: {reservation.confirmationCode}
                      </p>
                      <p className="text-sm text-gray-600">
                        السيارة: {reservation.carNumber}
                      </p>
                      <p className="text-sm text-gray-600">
                        {new Date(reservation.startTime).toLocaleDateString("ar-SA")}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className={`badge-primary text-xs ${
                          reservation.status === 'confirmed' ? 'bg-green-100 text-green-700' :
                          reservation.status === 'cancelled' ? 'bg-red-100 text-red-700' :
                          'bg-yellow-100 text-yellow-700'
                        }`}>
                          {reservation.status === 'confirmed' ? 'مؤكد' :
                           reservation.status === 'cancelled' ? 'ملغى' : 'قيد الانتظار'}
                        </span>
                        <span className="text-sm font-semibold text-primary">
                          {reservation.totalPrice} ريال
                        </span>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-blue-600"
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
