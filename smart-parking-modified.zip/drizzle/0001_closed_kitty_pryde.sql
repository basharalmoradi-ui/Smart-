CREATE TABLE `parking_spots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`spotNumber` varchar(50) NOT NULL,
	`location` varchar(255) NOT NULL,
	`floor` int NOT NULL,
	`pricePerHour` decimal(10,2) NOT NULL,
	`isAvailable` boolean NOT NULL DEFAULT true,
	`spotType` enum('standard','compact','accessible') NOT NULL DEFAULT 'standard',
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `parking_spots_id` PRIMARY KEY(`id`),
	CONSTRAINT `parking_spots_spotNumber_unique` UNIQUE(`spotNumber`)
);
--> statement-breakpoint
CREATE TABLE `reservations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`spotId` int NOT NULL,
	`carNumber` varchar(50) NOT NULL,
	`startTime` timestamp NOT NULL,
	`endTime` timestamp NOT NULL,
	`totalPrice` decimal(10,2) NOT NULL,
	`status` enum('pending','confirmed','cancelled','completed') NOT NULL DEFAULT 'pending',
	`confirmationCode` varchar(50) NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `reservations_id` PRIMARY KEY(`id`),
	CONSTRAINT `reservations_confirmationCode_unique` UNIQUE(`confirmationCode`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);