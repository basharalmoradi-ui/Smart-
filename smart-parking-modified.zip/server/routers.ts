import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import {
  getAllParkingSpots,
  getAvailableParkingSpots,
  getParkingSpotById,
  createParkingSpot,
  updateParkingSpot,
  deleteParkingSpot,
  createReservation,
  getReservationById,
  getReservationByConfirmationCode,
  getUserReservations,
  getAllReservations,
  updateReservation,
  cancelReservation,
  getReservationStats,
  getParkingStats,
} from "./db";
import { nanoid } from "nanoid";

// Admin-only procedure
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============= Parking Spots Routes =============
  parking: router({
    list: publicProcedure.query(async () => {
      return await getAllParkingSpots();
    }),

    available: publicProcedure.query(async () => {
      return await getAvailableParkingSpots();
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const spot = await getParkingSpotById(input.id);
        if (!spot) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Parking spot not found' });
        }
        return spot;
      }),

    create: adminProcedure
      .input(z.object({
        spotNumber: z.string().min(1),
        location: z.string().min(1),
        floor: z.number(),
        pricePerHour: z.string(),
        spotType: z.enum(['standard', 'compact', 'accessible']),
        description: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await createParkingSpot({
          spotNumber: input.spotNumber,
          location: input.location,
          floor: input.floor,
          pricePerHour: input.pricePerHour as any,
          spotType: input.spotType,
          description: input.description,
        });
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        spotNumber: z.string().optional(),
        location: z.string().optional(),
        floor: z.number().optional(),
        pricePerHour: z.string().optional(),
        isAvailable: z.boolean().optional(),
        spotType: z.enum(['standard', 'compact', 'accessible']).optional(),
        description: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        return await updateParkingSpot(id, updates as any);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await deleteParkingSpot(input.id);
      }),
  }),

  // ============= Reservations Routes =============
  reservations: router({
    create: protectedProcedure
      .input(z.object({
        spotId: z.number(),
        carNumber: z.string().min(1),
        startTime: z.date(),
        endTime: z.date(),
        totalPrice: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const spot = await getParkingSpotById(input.spotId);
        if (!spot) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Parking spot not found' });
        }

        if (!spot.isAvailable) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'Parking spot is not available' });
        }

        const confirmationCode = `PKG-${nanoid(8).toUpperCase()}`;

        const result = await createReservation({
          userId: ctx.user.id,
          spotId: input.spotId,
          carNumber: input.carNumber,
          startTime: input.startTime,
          endTime: input.endTime,
          totalPrice: input.totalPrice as any,
          confirmationCode,
          status: 'confirmed',
        });

        // Mark spot as unavailable
        await updateParkingSpot(input.spotId, { isAvailable: false });

        return { confirmationCode, success: true };
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const reservation = await getReservationById(input.id);
        if (!reservation) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Reservation not found' });
        }

        if (reservation.userId !== ctx.user.id && ctx.user.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Access denied' });
        }

        return reservation;
      }),

    getByCode: publicProcedure
      .input(z.object({ code: z.string() }))
      .query(async ({ input }) => {
        const reservation = await getReservationByConfirmationCode(input.code);
        if (!reservation) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Reservation not found' });
        }
        return reservation;
      }),

    myReservations: protectedProcedure.query(async ({ ctx }) => {
      return await getUserReservations(ctx.user.id);
    }),

    all: adminProcedure.query(async () => {
      return await getAllReservations();
    }),

    cancel: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const reservation = await getReservationById(input.id);
        if (!reservation) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Reservation not found' });
        }

        if (reservation.userId !== ctx.user.id && ctx.user.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Access denied' });
        }

        await cancelReservation(input.id);

        // Mark spot as available
        await updateParkingSpot(reservation.spotId, { isAvailable: true });

        return { success: true };
      }),
  }),

  // ============= Statistics Routes =============
  stats: router({
    reservations: adminProcedure.query(async () => {
      return await getReservationStats();
    }),

    parking: adminProcedure.query(async () => {
      return await getParkingStats();
    }),
  }),
});

export type AppRouter = typeof appRouter;
