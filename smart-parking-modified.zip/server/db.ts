import { eq, and, gte, lte, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, parkingSpots, reservations } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "phone"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============= Parking Spots Queries =============

export async function getAllParkingSpots() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(parkingSpots).orderBy(parkingSpots.spotNumber);
}

export async function getAvailableParkingSpots() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(parkingSpots).where(eq(parkingSpots.isAvailable, true)).orderBy(parkingSpots.location);
}

export async function getParkingSpotById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(parkingSpots).where(eq(parkingSpots.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createParkingSpot(spot: typeof parkingSpots.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(parkingSpots).values(spot);
  return result;
}

export async function updateParkingSpot(id: number, updates: Partial<typeof parkingSpots.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(parkingSpots).set(updates).where(eq(parkingSpots.id, id));
}

export async function deleteParkingSpot(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(parkingSpots).where(eq(parkingSpots.id, id));
}

// ============= Reservations Queries =============

export async function createReservation(reservation: typeof reservations.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(reservations).values(reservation);
  return result;
}

export async function getReservationById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(reservations).where(eq(reservations.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getReservationByConfirmationCode(code: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(reservations).where(eq(reservations.confirmationCode, code)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getUserReservations(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(reservations).where(eq(reservations.userId, userId)).orderBy(desc(reservations.createdAt));
}

export async function getAllReservations() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(reservations).orderBy(desc(reservations.createdAt));
}

export async function updateReservation(id: number, updates: Partial<typeof reservations.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(reservations).set(updates).where(eq(reservations.id, id));
}

export async function cancelReservation(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(reservations).set({ status: 'cancelled' }).where(eq(reservations.id, id));
}

// ============= Statistics Queries =============

export async function getReservationStats() {
  const db = await getDb();
  if (!db) return { total: 0, confirmed: 0, pending: 0, cancelled: 0 };

  const all = await db.select().from(reservations);
  
  return {
    total: all.length,
    confirmed: all.filter(r => r.status === 'confirmed').length,
    pending: all.filter(r => r.status === 'pending').length,
    cancelled: all.filter(r => r.status === 'cancelled').length,
    completed: all.filter(r => r.status === 'completed').length,
  };
}

export async function getParkingStats() {
  const db = await getDb();
  if (!db) return { total: 0, available: 0, occupied: 0 };

  const all = await db.select().from(parkingSpots);
  
  return {
    total: all.length,
    available: all.filter(s => s.isAvailable).length,
    occupied: all.filter(s => !s.isAvailable).length,
  };
}
